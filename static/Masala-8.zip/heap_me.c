#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct chunk {
    char *data;
    size_t size;
};

struct chunk *chunks[10];
int chunk_count = 0;

void menu() {
    printf("\n1. Chunk yaratish");
    printf("\n2. Chunk o'chirish");
    printf("\n3. Chunk ko'rish");
    printf("\n4. Chiqish\n");
    printf("\nTanlang: ");
}

void create_chunk() {
    if (chunk_count >= 10) {
        printf("Chunk limiti to'ldi!\n");
        return;
    }
    
    struct chunk *new_chunk = malloc(sizeof(struct chunk));
    printf("Chunk hajmini kiriting: ");
    scanf("%zu", &new_chunk->size);
    
    new_chunk->data = malloc(new_chunk->size);
    printf("Ma'lumot kiriting: ");
    scanf("%s", new_chunk->data);
    
    chunks[chunk_count++] = new_chunk;
    printf("Chunk yaratildi!\n");
}

void delete_chunk() {
    int index;
    printf("Chunk indeksini kiriting: ");
    scanf("%d", &index);
    
    if (index < 0 || index >= chunk_count) {
        printf("Noto'g'ri indeks!\n");
        return;
    }
    
    // Zaiflik: data free qilinmayapti
    free(chunks[index]);
    printf("Chunk o'chirildi!\n");
}

void view_chunk() {
    int index;
    printf("Chunk indeksini kiriting: ");
    scanf("%d", &index);
    
    if (index < 0 || index >= chunk_count) {
        printf("Noto'g'ri indeks!\n");
        return;
    }
    
    printf("Chunk ma'lumoti: %s\n", chunks[index]->data);
}

int main() {
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stdin, NULL, _IONBF, 0);
    
    printf("Heap Exploitation Challenge\n");
    
    int choice;
    while (1) {
        menu();
        scanf("%d", &choice);
        
        switch(choice) {
            case 1:
                create_chunk();
                break;
            case 2:
                delete_chunk();
                break;
            case 3:
                view_chunk();
                break;
            case 4:
                return 0;
            default:
                printf("Noto'g'ri tanlov!\n");
        }
    }
    
    return 0;
}